const starsContainer = document.getElementById("stars-container");

function createStars(numStars = 100) {
  // Clear only stars, not other elements
  starsContainer.innerHTML = ""; 

  const width = window.innerWidth;
  const height = window.innerHeight;

  for (let i = 0; i < numStars; i++) {
    const star = document.createElement("div");
    star.className = "star";
    star.style.top = Math.random() * height + "px";
    star.style.left = Math.random() * width + "px";
    starsContainer.appendChild(star);
  }
}

// Initial stars
createStars();

// Regenerate stars on resize
window.addEventListener("resize", () => {
  createStars();
});

// Hide menu when Play is clicked
const menuScreen = document.getElementById("menu-screen");
const playBtn = document.querySelector(".play-btn"); // first button = Play
const statsBtn = document.querySelector(".stats-btn");
const statsScreen = document.getElementById("stats-screen");
const ship = document.getElementById("ship");

// Ship state
let shipX = window.innerWidth / 2;
let shipY = window.innerHeight / 2;
let angle = 0; // in degrees
let velX = 0;
let velY = 0;
const thrust = 0.04;   // acceleration power
const friction = 0.99; // slow drift slightly

let keys = {};

function updateShip() {
  // Rotate left/right
  if (keys["a"]) angle -= 1.5;
  if (keys["d"]) angle += 1.5;

  // Apply thrust
  if (keys["w"]) {
    velX += Math.sin(angle * Math.PI / 180) * thrust;
    velY -= Math.cos(angle * Math.PI / 180) * thrust;
  }

  // Apply friction
  velX *= friction;
  velY *= friction;

  // Update position
  shipX += velX;
  shipY += velY;

  // Screen wrap (Asteroids style)
  if (shipX < 0) shipX = window.innerWidth;
  if (shipX > window.innerWidth) shipX = 0;
  if (shipY < 0) shipY = window.innerHeight;
  if (shipY > window.innerHeight) shipY = 0;

  // Apply CSS transform
  ship.style.left = shipX + "px";
  ship.style.top = shipY + "px";
  ship.style.transform = `translate(-50%, -50%) rotate(${angle}deg)`;
}

let gameRunning = false;
let loopId;

function gameLoop() {
  updateShip();
  loopId = requestAnimationFrame(gameLoop);
}

// Key handling
document.addEventListener("keydown", (e) => keys[e.key.toLowerCase()] = true);
document.addEventListener("keyup", (e) => keys[e.key.toLowerCase()] = false);

// Play button starts game
playBtn.addEventListener("click", () => {
  menuScreen.style.display = "none";
  statsScreen.style.display = "none";
  ship.style.display = "block";
  shipX = window.innerWidth / 2;
  shipY = window.innerHeight / 2;
  angle = 0;
  velX = velY = 0;

    gameRunning = true;
    gameLoop();
});

// Stats Screen
statsBtn.addEventListener("click", () => {
  menuScreen.style.display = "none";
  statsScreen.style.display = "block";
});

// Escape key returns to menu
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    ship.style.display = "none";
    statsScreen.style.display = "none";
    menuScreen.style.display = "block";
    gameRunning = false;

    cancelAnimationFrame(loopId)

    shipX = window.innerWidth / 2;
    shipY = window.innerHeight / 2;
    angle = 0;
    velX = 0;
    velY = 0;
  }
});

